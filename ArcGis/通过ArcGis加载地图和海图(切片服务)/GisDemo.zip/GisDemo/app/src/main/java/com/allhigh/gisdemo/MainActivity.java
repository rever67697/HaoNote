package com.allhigh.gisdemo;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.allhigh.gisdemo.map.HaituMapLayer;
import com.esri.android.map.GraphicsLayer;
import com.esri.android.map.MapView;
import com.esri.android.map.event.OnPanListener;
import com.esri.android.map.event.OnSingleTapListener;
import com.esri.android.map.event.OnZoomListener;
import com.esri.android.runtime.ArcGISRuntime;
import com.esri.core.geometry.GeometryEngine;
import com.esri.core.geometry.Point;
import com.esri.core.geometry.SpatialReference;
import com.esri.core.map.Graphic;

import java.util.HashMap;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class MainActivity extends AppCompatActivity{


//    private static XianChangFragment instance;

    Unbinder unbinder;


    @BindView(R.id.imageButton)
    ImageButton imageButton;
    @BindView(R.id.fl_xianChang_search)
    FrameLayout flXianChangSearch;
    @BindView(R.id.et_xianChang)
    EditText etXianChang;
    @BindView(R.id.mapView)
    MapView mapView;
    @BindView(R.id.rl_searchContainer)
    RelativeLayout rlSearchContainer;
    @BindView(R.id.tv_xianChang_boatName)
    TextView tvXianChangBoatName;
    @BindView(R.id.tv_xianChang_mmsi)
    TextView tvXianChangMmsi;
    @BindView(R.id.tv_xianChang_rotate)
    TextView tvXianChangRotate;
    @BindView(R.id.tv_xianChang_type)
    TextView tvXianChangType;
    @BindView(R.id.tv_xianChang_Speed)
    TextView tvXianChangSpeed;
    @BindView(R.id.tv_xianChangLastTime)
    TextView tvXianChangLastTime;
    @BindView(R.id.ll_boatDetail)
    LinearLayout llBoatDetail;
    @BindView(R.id.zoomControlView)
    ZoomControlView zoomControlView;
    @BindView(R.id.bt_xianChangAddTask)
    Button btXianChangAddTask;
    @BindView(R.id.rv_xianChang)
    RecyclerView rvXianChang;


    @BindView(R.id.bt_xianChangFooterView)
    Button btXianChangFooterView;
    @BindView(R.id.ll_xianChang)
    LinearLayout llXianChang;

    private int tag = -1;



    private HashMap<String, String> getBoatsAroundMap;


    private double mapViewHeight = 0;

    private double mapViewWidth = 0;


    //原点
    private Point originPoint = new Point(1.3518083477676086E7, 3414110.948134567);


    private GraphicsLayer graphicsLayer;

    private Drawable drawableYellow;


    private String boatName;


    private String shipTypeName;

    private String shipObjId;


    private String condition;

    //页数
    private int page = 1;

    private HashMap<String, String> queryBoatWithoutKeywordNewDataMap;

    private HashMap<String, String> queryBoatWithoutKeywordMoreDataMap;

    private HashMap<String, String> queryBoatWithKeywordNewDataMap;

    private HashMap<String, String> queryBoatWithKeywordMoreDataMap;

    private HashMap<String, String> queryBoatDetailMap;

//    private Rv_XianChangAdapter rv_woDeRenWuBoatQueryAdapter;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        getBoatsAroundMap = new HashMap<>();


        queryBoatWithoutKeywordNewDataMap = new HashMap<>();


        queryBoatWithoutKeywordMoreDataMap = new HashMap<>();


        queryBoatWithKeywordNewDataMap = new HashMap<>();


        queryBoatWithKeywordMoreDataMap = new HashMap<>();

        queryBoatDetailMap = new HashMap<>();

        //缩小的图片黄色的
        drawableYellow = zoomDrawable(getResources().getDrawable(R.drawable.a0), 60, 60);

        initMapView();

        initRv();

        //http://emap.shipdt.com/L05/R0000000b11/C0000001925.png
//        String rowValue = String.format("%08x",2833);
//        Log.e("hao", "rowValue: "+rowValue);
//        String rowName ="/R";
//        int rowLength = 7 - rowValue.length();
//        if (rowLength > 0) {
//            for(int i = 0; i < rowLength; i++) {
//                rowName += 0;
//            }
//        }
//        rowName += rowValue;
//        Log.e("hao", "rowName: "+rowName+);
    }

    private void initRv() {
        //设置布局管理器
//        rvXianChang.setLayoutManager(new LinearLayoutManager(MyApplication.getInstance()));
//
//        //适配器
//        rv_woDeRenWuBoatQueryAdapter = new Rv_XianChangAdapter(R.layout.rv_xianchang);
//
//
//        //点击事件
//        rv_woDeRenWuBoatQueryAdapter.setOnItemClickListener(new BaseQuickAdapter.OnItemClickListener() {
//            @Override
//            public void onItemClick(BaseQuickAdapter adapter, View view, int position) {
//
//                AisShipBasicDOBean data = (AisShipBasicDOBean) adapter.getData().get(position);
//
//                queryBoatDetailMap.put("objectType", "0");
//                queryBoatDetailMap.put("id", data.getMmsi());
//            }
//        });
//
//        //加载更多
//        rv_woDeRenWuBoatQueryAdapter.setOnLoadMoreListener(new BaseQuickAdapter.RequestLoadMoreListener() {
//            @Override
//            public void onLoadMoreRequested() {
//                loadMore();
//            }
//        }, rvXianChang);
//
//        //设置适配器
//        rvXianChang.setAdapter(rv_woDeRenWuBoatQueryAdapter);


    }


    //加载更多
    private void loadMore() {
//        if (TextUtils.isEmpty(condition)) {
//            //无条件搜索
//
//            queryBoatWithoutKeywordMoreDataMap.put("cnShipName", "");
//
//            queryBoatWithoutKeywordMoreDataMap.put("pageNo", page + "");
//
//            pXianChangFragment.queryBoatWithoutKeywordMoreData(queryBoatWithoutKeywordMoreDataMap);
//
//
//        } else {
//            //有条件搜索
//
//            queryBoatWithKeywordMoreDataMap.put("cnShipName", condition);
//
//            queryBoatWithKeywordMoreDataMap.put("pageNo", page + "");
//
//
//            pXianChangFragment.queryBoatWithKeywordMoreData(queryBoatWithKeywordMoreDataMap);
//
//
//        }
    }


    private void initMapView() {

        //去水印
        ArcGISRuntime.setClientId("Rj4Xn8knM2HXUEht");

        //去除背景网格

        HaituMapLayer haituMapLayer = new HaituMapLayer();


        mapView.addLayer(haituMapLayer);

        //设置最大放大尺寸
        mapView.setMaxScale(3332.6894049149);


        //设置最小放大尺寸
        // mapView.setMinScale(5.805307550495123E7);
        mapView.setMinScale(2.113120367020388E7);


        zoomControlView.setMapView(mapView);


        //默认定位在宁波海事处
        mapView.centerAt(originPoint, false);


        // 船舶图层
        graphicsLayer = new GraphicsLayer();


        mapView.addLayer(graphicsLayer);


        //比例缩放监听
        mapView.setOnZoomListener(new OnZoomListener() {
            @Override
            public void preAction(float v, float v1, double v2) {

                //缩放的时候 设置容器不可见
                llBoatDetail.setVisibility(View.GONE);


            }

            @Override
            public void postAction(float v, float v1, double v2) {

               /* graphicsLayer.removeAll();

                //如果比例尺再达到一定程度画船

                if (mapView.getScale() > Config.DRAWBOATSCALE) {
                    //画点
                    drawPoint();

                } else {

                    //画船
                    drawBoat();
                }*/

            }
        });


        // 地图操作事件
        // 平移
        mapView.setOnPanListener(new OnPanListener() {
            @Override
            public void postPointerMove(float fromx, float fromy, float tox, float toy) {

            }

            @Override
            public void postPointerUp(float fromx, float fromy, float tox, float toy) {


                //缩放后,如果比例尺达到一定程度,画点

                //如果比例尺再达到一定程度画船

                if (mapView.getScale() > 72223.819286) {
                    //画点
                    drawPoint();
                } else {

                    //画船
                    drawBoat();


                }


            }

            @Override
            public void prePointerMove(float fromx, float fromy, float tox, float toy) {
                //移动的时候 设置容器不可见

                llBoatDetail.setVisibility(View.GONE);


            }

            @Override
            public void prePointerUp(float fromx, float fromy, float tox, float toy) {

            }
        });


        //点击事件,点击获取要素

        mapView.setOnSingleTapListener(new OnSingleTapListener() {

            @Override
            public void onSingleTap(float v, float v1) {

             /*   Point point = mapView.toMapPoint(v, v1);

                //转经纬度
                Point p = (Point) GeometryEngine.project(point, SpatialReference.create(102113), SpatialReference.create(4326));


                MyLog.logNoTag("当前经度为" + p.getX() + "---当前纬度为" + p.getY());

                MyLog.logNoTag("当前比例尺" + mapView.getScale());*/


                if (mapView == null) {
                    return;
                }

//                if (mapView.getScale() > Config.DRAWBOATSCALE) {
//                    //不找点
//                    return;
//                }

                if (graphicsLayer.getNumberOfGraphics() == 0) {
                    //没有要素
                    return;
                }
                //比例尺小于标准值的,找船
                int[] indexes = graphicsLayer.getGraphicIDs(v, v1, 20);

                if (indexes == null || indexes.length < 1) {
                    llBoatDetail.setVisibility(View.GONE);
                    return;
                }
                try {
                    int selectedSegmentID = indexes[0];

                    Graphic graphic = graphicsLayer.getGraphic(selectedSegmentID);

                    //有目标
                    llBoatDetail.setVisibility(View.VISIBLE);

                    boatName = graphic.getAttributes().get("boatName") + "";

                    tvXianChangBoatName.setText(boatName);

                    //mmsi
                    tvXianChangMmsi.setText("MMSI:" + graphic.getAttributes().get("mmsi") + "");

                    //船首向
                    tvXianChangRotate.setText("船首向:" + graphic.getAttributes().get("direction") + "");

                    //船舶类别名字
                    shipTypeName = graphic.getAttributes().get("shipTypeName") + "";

                    tvXianChangType.setText("船舶类别:" + shipTypeName);

                    //速度
                    tvXianChangSpeed.setText("位置:" + graphic.getAttributes().get("speed") + "");

                    //objId


                    shipObjId = graphic.getAttributes().get("objId") + "";

                    //时间
                    tvXianChangLastTime.setText("最后时间:" + graphic.getAttributes().get("lastTime") + "");


                } catch (Exception ex) {

                    ex.printStackTrace();

                }

            }
        });

    }


    @OnClick({R.id.fl_xianChang_search, R.id.imageButton, R.id.bt_xianChangAddTask, R.id.bt_xianChangFooterView})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.fl_xianChang_search:

                //有条件查询或者无条件查询
                condition = etXianChang.getText().toString().trim();

                llBoatDetail.setVisibility(View.GONE);

                if (condition.contains(" ")) {
                    //去掉空格

                    condition = condition.replaceAll(" ", "");

                    // MyLog.logNoTag(condition + "之后的boatName");
                }


                if (TextUtils.isEmpty(condition)) {

//                    MyToast.toast("请输入关键字");

                    return;

                  /*  //无条件搜索
                    page = 1;

                    queryBoatWithoutKeywordNewDataMap.put("cnShipName", "");
                    queryBoatWithoutKeywordNewDataMap.put("pageNo", page + "");


                    pXianChangFragment.queryBoatWithoutKeywordNewData(queryBoatWithoutKeywordNewDataMap);
*/

                } else {
                    //有条件搜索
                    page = 1;

                    queryBoatWithKeywordNewDataMap.put("cnShipName", condition);

                    queryBoatWithKeywordNewDataMap.put("pageNo", page + "");


//                    pXianChangFragment.queryBoatWithKeywordNewData(queryBoatWithKeywordNewDataMap);


                }


                break;
            case R.id.imageButton:
                //点击完了之后,回到自己所在位置
                //获取自己的位置

                llXianChang.setVisibility(View.GONE);

                //经纬度转gis坐标
                Point gisPoint = (Point) GeometryEngine.project(new Point(121.6702322908654, 30.217849150709586), SpatialReference.create(4326), SpatialReference.create(102113));

                mapView.zoomToScale(gisPoint, 4622324.4343090001);


                //  drawZoomBoat(121.6702322908654, 30.217849150709586);


                break;

            case R.id.bt_xianChangAddTask:
                //添加船舶任务
//                Intent i = new Intent(MyApplication.getInstance(), XianChangFragment_chuanBoJianChaActivity.class);
//                i.putExtra("boatName", boatName);
//                i.putExtra("objId", shipObjId);
//                i.putExtra("shipTypeName", shipTypeName);
//                startActivity(i);

                break;

            case R.id.bt_xianChangFooterView:
                llXianChang.setVisibility(View.GONE);
                break;
        }
    }


//    @Override
//    public void queryBoatDistributedInfoResult(boolean isSuccess, List<AisShipBasicDO> data) {
//        if (isSuccess) {
//            //获取船舶分布图成功,绘制要素
//            //先移除要素
//            graphicsLayer.removeAll();
//
//
//            for (int i = 0; i < data.size(); i++) {
//
//                //经度
//                double lat = data.get(i).getLat();
//
//                //纬度
//                double lon = data.get(i).getLon();
//
//                //转gis坐标
//                Point point = new Point(lon, lat);
//
//                Point gisPoint = (Point) GeometryEngine.project(point, SpatialReference.create(4326), SpatialReference.create(102113));
//
//
//                CompositeSymbol shipSymbol = new CompositeSymbol();
//
//
//                //图片
//                PictureMarkerSymbol markerSymbol = new PictureMarkerSymbol(drawableYellow);
//
//                //船首向
//                markerSymbol.setAngle(getDirection(data.get(i).getTrueHeading(), data.get(i).getCog()));
//
//
//                String boatName = "";
//
//                if (TextUtils.isEmpty(data.get(i).getShipCName())) {
//                    boatName = data.get(i).getMmsi();
//                } else {
//                    boatName = data.get(i).getShipCName();
//                }
//
//                data.get(i).getShipCName();
//
//
//                TextSymbol textSymbol = new TextSymbol(12, boatName, Color.BLACK);
//
//                shipSymbol.add(textSymbol);
//
//                shipSymbol.add(markerSymbol);
//
//
//                //属性的map
//                Map<String, Object> attributes = new HashMap<>();
//
//                //属性
//
//                // 船名
//                attributes.put("boatName", boatName);
//
//                //mmsi
//                attributes.put("mmsi", data.get(i).getMmsi());
//
//                //船首向
//                attributes.put("direction", getDirection(data.get(i).getTrueHeading(), data.get(i).getCog()));
//
//                //船舶类别名字
//                attributes.put("shipTypeName", MyUtils.getShipTypeName(data.get(i).getShipType()));
//
//
//                //时间
//                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
//
//                if (data.get(i).getTime() != null) {
//
//                    attributes.put("lastTime", sdf.format(data.get(i).getTime()));
//
//                }
//
//                //速度
//                attributes.put("speed", lon + "," + lat);
//
//
//                //objId
//                attributes.put("objId", data.get(i).getShipId());
//
//
//                Graphic graphic = new Graphic(gisPoint, shipSymbol, attributes);
//
//
//                graphicsLayer.addGraphic(graphic);
//
//
//            }
//
//
//        } else {
//
//        }
//    }

//    @Override
//    public void queryBoatDistributedInfoResult2(boolean isSuccess, List<AisShipBasicDO> data) {
//        if (isSuccess) {
//            //查询船舶分布成功
//
//            //先移除要素
//            graphicsLayer.removeAll();
//
//
//            //画点
//            for (int i = 0; i < data.size(); i++) {
//
//                //每一个点的经纬度
//
//                //经度
//                double lat = data.get(i).getLat();
//
//                //纬度
//                double lon = data.get(i).getLon();
//
//                //转gis坐标
//                Point point = new Point(lon, lat);
//
//
//                Point gisPoint = (Point) GeometryEngine.project(point, SpatialReference.create(4326), SpatialReference.create(102113));
//
//                //画图
//                SimpleMarkerSymbol pointSymbol = new SimpleMarkerSymbol(Color.GREEN, 10, SimpleMarkerSymbol.STYLE.DIAMOND);
//
//                Graphic graphic = new Graphic(gisPoint, pointSymbol);
//
//                graphicsLayer.addGraphic(graphic);
//
//            }
//
//        }
//    }
//
//    @Override
//    public void queryDefaultBoatDistributedInfoResult(boolean isSuccess, List<AisShipBasicDO> data) {
//        if (isSuccess) {
//            //查询船舶分布成功
//
//            //先移除要素
//            graphicsLayer.removeAll();
//
//
//            //画点
//            for (int i = 0; i < data.size(); i++) {
//
//                //每一个点的经纬度
//
//                //经度
//                double lat = data.get(i).getLat();
//
//                //纬度
//                double lon = data.get(i).getLon();
//
//                //转gis坐标
//                Point point = new Point(lon, lat);
//
//
//                Point gisPoint = (Point) GeometryEngine.project(point, SpatialReference.create(4326), SpatialReference.create(102113));
//
//                //画图
//                //图片
//                SimpleMarkerSymbol pointSymbol = new SimpleMarkerSymbol(Color.GREEN, 5, SimpleMarkerSymbol.STYLE.DIAMOND);
//
//                Graphic graphic = new Graphic(gisPoint, pointSymbol);
//
//                graphicsLayer.addGraphic(graphic);
//
//            }
//
//        }
//    }

//    @Override
//    public void queryZoomBoatDistributedInfoResult(boolean isSuccess, List<AisShipBasicDO> data) {
//        //这里肯定是画船
//        if (isSuccess) {
//            //获取船舶分布图成功,绘制要素
//            //先移除要素
//            graphicsLayer.removeAll();
//
//
//            for (int i = 0; i < data.size(); i++) {
//
//                //经度
//                double lat = data.get(i).getLat();
//
//                //纬度
//                double lon = data.get(i).getLon();
//
//                //转gis坐标
//                Point point = new Point(lon, lat);
//
//
//                Point gisPoint = (Point) GeometryEngine.project(point, SpatialReference.create(4326), SpatialReference.create(102113));
//
//
//                CompositeSymbol shipSymbol = new CompositeSymbol();
//
//
//                //图片
//                PictureMarkerSymbol markerSymbol = new PictureMarkerSymbol(drawableYellow);
//
//                //船首向
//                markerSymbol.setAngle(getDirection(data.get(i).getTrueHeading(), data.get(i).getCog()));
//
//
//                String boatName = "";
//
//                if (TextUtils.isEmpty(data.get(i).getShipCName())) {
//                    boatName = data.get(i).getMmsi();
//                } else {
//                    boatName = data.get(i).getShipCName();
//                }
//
//
//                TextSymbol textSymbol = new TextSymbol(12, boatName, Color.BLACK);
//
//                shipSymbol.add(textSymbol);
//
//                shipSymbol.add(markerSymbol);
//
//
//                //属性的map
//                Map<String, Object> attributes = new HashMap<>();
//
//                //属性
//                // 船名
//                attributes.put("boatName", boatName);
//
//                //mmsi
//                attributes.put("mmsi", data.get(i).getMmsi());
//
//
//                //船首向
//                attributes.put("direction", getDirection(data.get(i).getTrueHeading(), data.get(i).getCog()));
//
//
//                //船舶类别名字
//                attributes.put("shipTypeName", MyUtils.getShipTypeName(data.get(i).getShipType()));
//
//                //速度
//                attributes.put("speed", lon + "," + lat);
//
//
//                //时间
//                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
//
//                if (data.get(i).getTime() != null) {
//
//                    attributes.put("lastTime", sdf.format(data.get(i).getTime()));
//
//                }
//
//                //objId
//                attributes.put("objId", data.get(i).getShipId());
//
//
//                Graphic graphic = new Graphic(gisPoint, shipSymbol, attributes);
//
//
//                graphicsLayer.addGraphic(graphic);
//
//
//            }
//
//        } else {
//
//        }
//    }

//    @Override
//    public void queryBoatWithoutKeywordNewDataResult(boolean isSuccess, AllBoatQueryBean datas) {
//
//
//    }
//
//    @Override
//    public void queryBoatWithoutKeyWordMoreDataResult(boolean isSuccess, AllBoatQueryBean datas) {
//
//
//    }
//
//    @Override
//    public void queryBoatWithKeywordNewDataResult(boolean isSuccess, List<AisShipBasicDOBean> datas) {
//
//
//        if (isSuccess) {
//            //设置数据
//            llXianChang.setVisibility(View.VISIBLE);
//
//            rv_woDeRenWuBoatQueryAdapter.setNewData(datas);
//
//
//            if (datas.isEmpty()) {
//                rv_woDeRenWuBoatQueryAdapter.loadMoreEnd();
//            } else {
//                //page=2
//                page = 2;
//                rv_woDeRenWuBoatQueryAdapter.loadMoreComplete();
//            }
//
//
//        } else {
//            rv_woDeRenWuBoatQueryAdapter.loadMoreEnd();
//        }
//    }
//
//    @Override
//    public void queryBoatWithKeywordMoreDataResult(boolean isSuccess, List<AisShipBasicDOBean> datas) {
//
//
//        if (isSuccess) {
//
//            llXianChang.setVisibility(View.VISIBLE);
//            if (datas.size() != 0) {
//                //设置数据
//                rv_woDeRenWuBoatQueryAdapter.addData(datas);
//
//                if (datas.isEmpty()) {
//                    rv_woDeRenWuBoatQueryAdapter.loadMoreEnd();
//                } else {
//                    //page++
//                    page++;
//
//                    rv_woDeRenWuBoatQueryAdapter.loadMoreComplete();
//                }
//
//
//            } else {
//                rv_woDeRenWuBoatQueryAdapter.loadMoreEnd();
//            }
//
//
//        } else {
//
//            rv_woDeRenWuBoatQueryAdapter.loadMoreEnd();
//        }
//    }
//
//    @Override
//    public void getBoatDetailResult(boolean isSuccess, XianChangFragmentBoatDetailsBean data) {
//
//        if (isSuccess) {
//            llXianChang.setVisibility(View.GONE);
//
//
//            graphicsLayer.removeAll();
//            //经度
//            double lat = Double.parseDouble(data.getLat());
//
//            //纬度
//            double lon = Double.parseDouble(data.getLon());
//
//            //转gis坐标
//            Point point = new Point(lon, lat);
//
//            MyLog.logNoTag(lon + "." + lat);
//
//
//            Point gisPoint = (Point) GeometryEngine.project(point, SpatialReference.create(4326), SpatialReference.create(102113));
//
//
//            mapView.zoomToScale(gisPoint, Config.DRAWBOATSCALE);
//
//
//            CompositeSymbol shipSymbol = new CompositeSymbol();
//
//
//            //图片
//            PictureMarkerSymbol markerSymbol = new PictureMarkerSymbol(drawableYellow);
//
//            //船首向
//            markerSymbol.setAngle(getDirection(Double.parseDouble(data.getTrueHeading()), Double.parseDouble(data.getCog())));
//
//
//            String boatName = "";
//
//            if (TextUtils.isEmpty(data.getShipCName())) {
//                boatName = data.getMmsi();
//            } else {
//                boatName = data.getShipCName();
//            }
//
//
//            TextSymbol textSymbol = new TextSymbol(12, boatName, Color.BLACK);
//
//            shipSymbol.add(textSymbol);
//
//            shipSymbol.add(markerSymbol);
//
//
//            //属性的map
//            Map<String, Object> attributes = new HashMap<>();
//
//            //属性
//            // 船名
//            attributes.put("boatName", boatName);
//
//            //mmsi
//            attributes.put("mmsi", data.getMmsi());
//
//
//            //船首向
//            attributes.put("direction", getDirection(Double.parseDouble(data.getTrueHeading()), Double.parseDouble(data.getCog())));
//
//
//            //船舶类别名字
//            attributes.put("shipTypeName", MyUtils.getShipTypeName(Integer.parseInt(data.getShipType())));
//
//            //速度
//            attributes.put("speed", lon + "," + lat);
//
//
//            if (data.getTime() != null) {
//
//                attributes.put("lastTime", data.getTime());
//
//            }
//
//            //objId
//            attributes.put("objId", data.getShipId());
//
//
//            Graphic graphic = new Graphic(gisPoint, shipSymbol, attributes);
//
//
//            graphicsLayer.addGraphic(graphic);
//
//
//        } else {
//
//        }
//    }
//


    @Override
    public void onPause() {
        super.onPause();
        mapView.pause();
    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.unpause();

    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    //缩放drawable
    private Drawable zoomDrawable(Drawable drawable, int w, int h) {
        int width = drawable.getIntrinsicWidth();
        int height = drawable.getIntrinsicHeight();
        Bitmap oldbmp = drawableToBitmap(drawable);
        Matrix matrix = new Matrix();
        float scaleWidth = ((float) w / width);
        float scaleHeight = ((float) h / height);
        matrix.postScale(scaleWidth, scaleHeight);
        Bitmap newbmp = Bitmap.createBitmap(oldbmp, 0, 0, width, height,
                matrix, true);
        return new BitmapDrawable(null, newbmp);
    }

    private Bitmap drawableToBitmap(Drawable drawable) {
        int width = drawable.getIntrinsicWidth();
        int height = drawable.getIntrinsicHeight();
        Bitmap.Config config = drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888
                : Bitmap.Config.RGB_565;
        Bitmap bitmap = Bitmap.createBitmap(width, height, config);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, width, height);
        drawable.draw(canvas);
        return bitmap;
    }


    //获取左上角点横坐标
    private float getLeftTopPointX(Point center) {

        float leftTopPointX = (float) (center.getX() - (getMapViewWidth() / 2));
        return leftTopPointX;
    }

    //获取左上角点纬度
    private float getLeftTopPointY(Point center) {


        float leftTopPointY = (float) (center.getY() - getMapViewHeight() / 2);

        return leftTopPointY;
    }


    //获取右上角点横坐标
    private float getRightTopPointX(Point center) {

        float rightTopPointX = (float) (center.getX() + (getMapViewWidth() / 2));

        return rightTopPointX;
    }


    //获取右上角点纵坐标
    private float getRightTopPointY(Point center) {


        float rightTopPointY = (float) (center.getY() - getMapViewHeight() / 2);

        return rightTopPointY;
    }


    //获取左下角点纵坐标
    private float getLeftBottomPointX(Point center) {

        float leftBottomPointX = (float) (center.getX() - (getMapViewWidth() / 2));

        return leftBottomPointX;
    }


    //获取左下角点纵坐标
    private float getLeftBottomPointY(Point center) {


        float leftBottomPointY = (float) (center.getY() + getMapViewHeight() / 2);

        return leftBottomPointY;
    }


    //获取右下角点横坐标
    private float getRightBottomPointX(Point center) {

        float rightBottomPointX = (float) (center.getX() + (getMapViewWidth() / 2));

        return rightBottomPointX;
    }


    //获取右下角点纵坐标
    private float getRightBottomPointY(Point center) {


        float rightBottomPointY = (float) (center.getY() + getMapViewHeight() / 2);

        return rightBottomPointY;
    }


    private void drawBoat() {

//        if (Kits.NetWork.getNetworkType(MyApplication.getInstance()) == -1) {
//
//            MyToast.toast("请检查网络连接");
//
//            return;
//
//        }

        //当前gis坐标
        Point center = mapView.getCenter();

        if (center.isEmpty()) {
//            MyToast.toast("海图中心坐标丢失");
            return;
        }

        // MyLog.logNoTag("当前gis为" + center.getX());

        //gis中心点转屏幕坐标
        Point screenPoint = mapView.toScreenPoint(center);
        if (screenPoint.isEmpty()) {
//            MyToast.toast("海图中心坐标丢失");
            return;
        }


        //  MyLog.logNoTag("当前屏幕坐标为" + screenPoint.getX() + "-" + screenPoint.getY());

        //那么屏幕4个点的坐标应该为
        //左上角的横坐标为
        float leftTopPointX = getLeftTopPointX(screenPoint);
        //左上角的纵坐标为
        float leftTopPointY = getLeftTopPointY(screenPoint);

        //左上角gis坐标
        Point leftTopGisPoint = mapView.toMapPoint(leftTopPointX, leftTopPointY);


        if (leftTopGisPoint.isEmpty()) {
//            MyToast.toast("海图左上角坐标丢失");
            return;
        }


        //左上角经纬度
        Point leftTopPoint = (Point) GeometryEngine.project(leftTopGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (leftTopPoint.isEmpty()) {
//            MyToast.toast("海图左上角坐标丢失");
            return;
        }


        //右上角的横坐标为
        float rightTopPointX = getRightTopPointX(screenPoint);
        //右上角的纵坐标为
        float rightTopPointY = getRightTopPointY(screenPoint);

        //右上角的gis坐标为
        Point rightTopGisPoint = mapView.toMapPoint(rightTopPointX, rightTopPointY);

        if (rightTopGisPoint.isEmpty()) {
//            MyToast.toast("海图右上角坐标丢失");
            return;
        }


        //右上角的经纬度为
        Point rightTopPoint = (Point) GeometryEngine.project(rightTopGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (rightTopPoint.isEmpty()) {
//            MyToast.toast("海图右上角坐标丢失");
            return;
        }

        //  MyLog.logNoTag("右上角经纬度为" + rightTopPoint.getX() + "++" + rightTopPoint.getY());


        //左下角的横坐标为
        float leftBottomPointX = getLeftBottomPointX(screenPoint);

        //左下角的纵坐标
        float leftBottomPointY = getLeftBottomPointY(screenPoint);

        //左下角的gis坐标
        Point leftBottomGisPoint = mapView.toMapPoint(leftBottomPointX, leftBottomPointY);

        if (leftBottomGisPoint.isEmpty()) {
//            MyToast.toast("海图左下角坐标丢失");
            return;
        }


        //左下角的经纬度
        Point leftBottomPoint = (Point) GeometryEngine.project(leftBottomGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (leftBottomPoint.isEmpty()) {
//            MyToast.toast("海图左下角坐标丢失");
            return;
        }


        //  MyLog.logNoTag("左下角坐标为" + leftBottomPoint.getX() + "++" + leftBottomPoint.getY());


        //右下角的横坐标为
        float rightBottomPointX = getRightBottomPointX(screenPoint);

        //右下角的纵坐标为
        float rightBottomPointY = getRightBottomPointY(screenPoint);

        //右下角的gis坐标为

        Point rightBottomGisPoint = mapView.toMapPoint(rightBottomPointX, rightBottomPointY);

        if (rightBottomGisPoint.isEmpty()) {
//            MyToast.toast("海图右下角坐标丢失");
            return;
        }


        //右下角的经纬度

        Point rightBottomPoint = (Point) GeometryEngine.project(rightBottomGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (rightBottomPoint.isEmpty()) {
//            MyToast.toast("海图右下角坐标丢失");
            return;
        }


        // MyLog.logNoTag("右下角坐标为" + rightBottomPoint.getX() + "++" + rightBottomPoint.getY());


        //发起请求,获取附近的船信息

        getBoatsAroundMap.put("latitude1", rightBottomPoint.getY() + "");
        getBoatsAroundMap.put("longitude1", leftTopPoint.getX() + "");
        getBoatsAroundMap.put("latitude2", leftTopPoint.getY() + "");
        getBoatsAroundMap.put("longitude2", rightBottomPoint.getX() + "");
        getBoatsAroundMap.put("isConvert", 1 + "");


//        pXianChangFragment.queryBoatDistributedInfo(getBoatsAroundMap);

    }


    private void drawPoint() {

//        if (Kits.NetWork.getNetworkType(MyApplication.getInstance()) == -1) {
//
//            MyToast.toast("请检查网络连接");
//            return;
//
//        }


        //当前gis坐标
        Point center = mapView.getCenter();

        if (center.isEmpty()) {
//            MyToast.toast("海图中心坐标丢失");
            return;
        }

        // MyLog.logNoTag("当前gis为" + center.getX());

        //gis中心点转屏幕坐标
        Point screenPoint = mapView.toScreenPoint(center);
        if (screenPoint.isEmpty()) {
//            MyToast.toast("海图中心坐标丢失");
            return;
        }


        //  MyLog.logNoTag("当前屏幕坐标为" + screenPoint.getX() + "-" + screenPoint.getY());

        //那么屏幕4个点的坐标应该为
        //左上角的横坐标为
        float leftTopPointX = getLeftTopPointX(screenPoint);
        //左上角的纵坐标为
        float leftTopPointY = getLeftTopPointY(screenPoint);

        //左上角gis坐标
        Point leftTopGisPoint = mapView.toMapPoint(leftTopPointX, leftTopPointY);


        if (leftTopGisPoint.isEmpty()) {
//            MyToast.toast("海图左上角坐标丢失");
            return;
        }


        //左上角经纬度
        Point leftTopPoint = (Point) GeometryEngine.project(leftTopGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (leftTopPoint.isEmpty()) {
//            MyToast.toast("海图左上角坐标丢失");
            return;
        }

        //  MyLog.logNoTag("左上角经纬度为" + leftTopPoint.getX() + "++" + leftTopPoint.getY());


        //右上角的横坐标为
        float rightTopPointX = getRightTopPointX(screenPoint);
        //右上角的纵坐标为
        float rightTopPointY = getRightTopPointY(screenPoint);

        //右上角的gis坐标为
        Point rightTopGisPoint = mapView.toMapPoint(rightTopPointX, rightTopPointY);

        if (rightTopGisPoint.isEmpty()) {
//            MyToast.toast("海图右上角坐标丢失");
            return;
        }


        //右上角的经纬度为
        Point rightTopPoint = (Point) GeometryEngine.project(rightTopGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (rightTopPoint.isEmpty()) {
//            MyToast.toast("海图右上角坐标丢失");
            return;
        }

        //    MyLog.logNoTag("右上角经纬度为" + rightTopPoint.getX() + "++" + rightTopPoint.getY());


        //左下角的横坐标为
        float leftBottomPointX = getLeftBottomPointX(screenPoint);

        //左下角的纵坐标
        float leftBottomPointY = getLeftBottomPointY(screenPoint);

        //左下角的gis坐标
        Point leftBottomGisPoint = mapView.toMapPoint(leftBottomPointX, leftBottomPointY);

        if (leftBottomGisPoint.isEmpty()) {
//            MyToast.toast("海图左下角坐标丢失");
            return;
        }


        //左下角的经纬度
        Point leftBottomPoint = (Point) GeometryEngine.project(leftBottomGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (leftBottomPoint.isEmpty()) {
//            MyToast.toast("海图左下角坐标丢失");
            return;
        }


        //   MyLog.logNoTag("左下角坐标为" + leftBottomPoint.getX() + "++" + leftBottomPoint.getY());


        //右下角的横坐标为
        float rightBottomPointX = getRightBottomPointX(screenPoint);

        //右下角的纵坐标为
        float rightBottomPointY = getRightBottomPointY(screenPoint);

        //右下角的gis坐标为

        Point rightBottomGisPoint = mapView.toMapPoint(rightBottomPointX, rightBottomPointY);


        if (rightBottomGisPoint.isEmpty()) {
//            MyToast.toast("海图右下角坐标丢失");
            return;
        }


        //右下角的经纬度

        Point rightBottomPoint = (Point) GeometryEngine.project(rightBottomGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (rightBottomPoint.isEmpty()) {
//            MyToast.toast("海图右下角坐标丢失");
            return;
        }


        // MyLog.logNoTag("右下角坐标为" + rightBottomPoint.getX() + "++" + rightBottomPoint.getY());


        //发起请求,获取附近的船信息

        getBoatsAroundMap.put("latitude1", rightBottomPoint.getY() + "");
        getBoatsAroundMap.put("longitude1", leftTopPoint.getX() + "");
        getBoatsAroundMap.put("latitude2", leftTopPoint.getY() + "");
        getBoatsAroundMap.put("longitude2", rightBottomPoint.getX() + "");
        getBoatsAroundMap.put("isConvert", 1 + "");


//        pXianChangFragment.queryBoatDistributedInfo2(getBoatsAroundMap);


    }


    private void drawZoomBoat(double la, double lo) {
        //当前经纬度坐标
        Point point = new Point(la, lo);

        if (point.isEmpty()) {
//            MyToast.toast("海图中心坐标丢失");
            return;
        }

        //转gis坐标
        Point center = (Point) GeometryEngine.project(point, SpatialReference.create(4326), SpatialReference.create(102113));
        if (center.isEmpty()) {
//            MyToast.toast("海图中心坐标丢失");
            return;
        }


        // MyLog.logNoTag("当前gis为" + center.getX());

        //gis中心点转屏幕坐标
        Point screenPoint = mapView.toScreenPoint(center);
        if (screenPoint.isEmpty()) {
//            MyToast.toast("海图中心坐标丢失");
            return;
        }


        //  MyLog.logNoTag("当前屏幕坐标为" + screenPoint.getX() + "-" + screenPoint.getY());

        //那么屏幕4个点的坐标应该为
        //左上角的横坐标为
        float leftTopPointX = getLeftTopPointX(screenPoint);
        //左上角的纵坐标为
        float leftTopPointY = getLeftTopPointY(screenPoint);

        //左上角gis坐标
        Point leftTopGisPoint = mapView.toMapPoint(leftTopPointX, leftTopPointY);


        if (leftTopGisPoint.isEmpty()) {
//            MyToast.toast("海图左上角坐标丢失");
            return;
        }


        //左上角经纬度
        Point leftTopPoint = (Point) GeometryEngine.project(leftTopGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (leftTopPoint.isEmpty()) {
//            MyToast.toast("海图左上角坐标丢失");
            return;
        }

        // MyLog.logNoTag("左上角经纬度为" + leftTopPoint.getX() + "++" + leftTopPoint.getY());


        //右上角的横坐标为
        float rightTopPointX = getRightTopPointX(screenPoint);
        //右上角的纵坐标为
        float rightTopPointY = getRightTopPointY(screenPoint);

        //右上角的gis坐标为
        Point rightTopGisPoint = mapView.toMapPoint(rightTopPointX, rightTopPointY);

        if (rightTopGisPoint.isEmpty()) {
//            MyToast.toast("海图右上角坐标丢失");
            return;
        }


        //右上角的经纬度为
        Point rightTopPoint = (Point) GeometryEngine.project(rightTopGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (rightTopPoint.isEmpty()) {
//            MyToast.toast("海图右上角坐标丢失");
            return;
        }

        //   MyLog.logNoTag("右上角经纬度为" + rightTopPoint.getX() + "++" + rightTopPoint.getY());


        //左下角的横坐标为
        float leftBottomPointX = getLeftBottomPointX(screenPoint);

        //左下角的纵坐标
        float leftBottomPointY = getLeftBottomPointY(screenPoint);

        //左下角的gis坐标
        Point leftBottomGisPoint = mapView.toMapPoint(leftBottomPointX, leftBottomPointY);

        if (leftBottomGisPoint.isEmpty()) {
//            MyToast.toast("海图左下角坐标丢失");
            return;
        }


        //左下角的经纬度
        Point leftBottomPoint = (Point) GeometryEngine.project(leftBottomGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (leftBottomPoint.isEmpty()) {
//            MyToast.toast("海图左下角坐标丢失");
            return;
        }


        //   MyLog.logNoTag("左下角坐标为" + leftBottomPoint.getX() + "++" + leftBottomPoint.getY());


        //右下角的横坐标为
        float rightBottomPointX = getRightBottomPointX(screenPoint);

        //右下角的纵坐标为
        float rightBottomPointY = getRightBottomPointY(screenPoint);

        //右下角的gis坐标为

        Point rightBottomGisPoint = mapView.toMapPoint(rightBottomPointX, rightBottomPointY);

        if (rightBottomGisPoint.isEmpty()) {
//            MyToast.toast("海图右下角坐标丢失");
            return;
        }


        //右下角的经纬度

        Point rightBottomPoint = (Point) GeometryEngine.project(rightBottomGisPoint, SpatialReference.create(102113), SpatialReference.create(4326));

        if (rightBottomPoint.isEmpty()) {
//            MyToast.toast("海图右下角坐标丢失");
            return;
        }


        //发起请求,获取附近的船信息

        getBoatsAroundMap.put("latitude1", rightBottomPoint.getY() + "");
        getBoatsAroundMap.put("longitude1", leftTopPoint.getX() + "");
        getBoatsAroundMap.put("latitude2", leftTopPoint.getY() + "");
        getBoatsAroundMap.put("longitude2", rightBottomPoint.getX() + "");
        getBoatsAroundMap.put("isConvert", 1 + "");

//        pXianChangFragment.queryZoomBoatDistributedInfo(getBoatsAroundMap);

    }


    //获取mapview高度
    private double getMapViewHeight() {

        mapView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {

                mapViewHeight = mapView.getHeight();

                mapView.getViewTreeObserver().removeGlobalOnLayoutListener(this);

            }
        });


        return mapViewHeight;
    }


    //获取mapview宽度
    private double getMapViewWidth() {

        mapView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {

                mapViewWidth = mapView.getWidth();
                mapView.getViewTreeObserver().removeGlobalOnLayoutListener(this);

            }
        });


        return mapViewWidth;
    }


    // 获取最佳的船首向
    private float getDirection(double refdirection, double direction) {
        float value = 0;
        if (refdirection >= 0 && refdirection < 360) {
            value = (float) refdirection;
        } else {
            value = (float) direction;
        }
        while (value > 360.0) {
            value -= 360.0;
        }
        return value;
    }


}
