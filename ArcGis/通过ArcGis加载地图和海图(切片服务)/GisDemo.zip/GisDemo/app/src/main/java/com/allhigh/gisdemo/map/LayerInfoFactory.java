package com.allhigh.gisdemo.map;


/**
 * Created by songke on 2018/4/23.
 */

/*
public class LayerInfoFactory {

    private static final String MAPURl = "http://mt2.google.cn/vt/lyrs=m@180000000&hl=zh-CN&gl=cn&src=app";


    private static final Point ORIGIN_2000 = new Point(-180, 90,
            SpatialReference.create(LayerInfoFactory.SRID_2000));




    private static final int SRID_2000 = 4326;

    //切片的大小

    private static final double X_MIN_2000 = -180;

    private static final double Y_MIN_2000 = -90;

    private static final double X_MAX_2000 = 180;

    //距离边框的距离
    private static final double Y_MAX_2000 = 90;


    private static final double[] SCALES = {2.958293554545656E8,
            1.479146777272828E8, 7.39573388636414E7, 3.69786694318207E7,
            1.848933471591035E7, 9244667.357955175, 4622333.678977588,
            2311166.839488794, 1155583.419744397, 577791.7098721985,
            288895.85493609926, 144447.92746804963, 72223.96373402482,
            36111.98186701241, 18055.990933506204, 9027.995466753102,
            4513.997733376551, 2256.998866688275, 1127.2338602399827,
            563.6169301199914};


    private static final double[] RESOLUTIONS_2000 = {0.7031249999891485,
            0.35156249999999994, 0.17578124999999997, 0.08789062500000014,
            0.04394531250000007, 0.021972656250000007, 0.01098632812500002,
            0.00549316406250001, 0.0027465820312500017, 0.0013732910156250009,
            0.000686645507812499, 0.0003433227539062495,
            0.00017166137695312503, 0.00008583068847656251,
            0.000042915344238281406, 0.000021457672119140645,
            0.000010728836059570307, 0.000005364418029785169};


  */
/*  private static final double[] RESOLUTIONS_Me = {
            78271.51696402048, 39135.75848201024,
            19567.87924100512, 9783.93962050256,
            4891.96981025128, 2445.98490512564,
            1222.99245256282, 611.49622628141,
            305.748113140705, 152.8740565703525,
            76.43702828517625, 38.21851414258813,
            19.109257071294063, 9.554628535647032,
            4.777314267823516, 2.388657133911758,
            1.194328566955879, 0.5971642834779395,
            0.298582141738970};
*//*


    private static List<LevelOfDetail> getLods2000() {
        List<LevelOfDetail> lods = new ArrayList<LevelOfDetail>();
        lods.add(new LevelOfDetail(1, RESOLUTIONS_2000[0], SCALES[0]));
        lods.add(new LevelOfDetail(2, RESOLUTIONS_2000[1], SCALES[1]));
        lods.add(new LevelOfDetail(3, RESOLUTIONS_2000[2], SCALES[2]));
        lods.add(new LevelOfDetail(4, RESOLUTIONS_2000[3], SCALES[3]));
        lods.add(new LevelOfDetail(5, RESOLUTIONS_2000[4], SCALES[4]));
        lods.add(new LevelOfDetail(6, RESOLUTIONS_2000[5], SCALES[5]));
        lods.add(new LevelOfDetail(7, RESOLUTIONS_2000[6], SCALES[6]));
        lods.add(new LevelOfDetail(8, RESOLUTIONS_2000[7], SCALES[7]));
        lods.add(new LevelOfDetail(9, RESOLUTIONS_2000[8], SCALES[8]));
        lods.add(new LevelOfDetail(10, RESOLUTIONS_2000[9], SCALES[9]));
        lods.add(new LevelOfDetail(11, RESOLUTIONS_2000[10], SCALES[10]));
        lods.add(new LevelOfDetail(12, RESOLUTIONS_2000[11], SCALES[11]));
        lods.add(new LevelOfDetail(13, RESOLUTIONS_2000[12], SCALES[12]));
        lods.add(new LevelOfDetail(14, RESOLUTIONS_2000[13], SCALES[13]));
        lods.add(new LevelOfDetail(15, RESOLUTIONS_2000[14], SCALES[14]));
        lods.add(new LevelOfDetail(16, RESOLUTIONS_2000[15], SCALES[15]));
        lods.add(new LevelOfDetail(17, RESOLUTIONS_2000[16], SCALES[16]));
        lods.add(new LevelOfDetail(18, RESOLUTIONS_2000[17], SCALES[17]));
        return lods;
    }


    public static HaiTuLayerInfo getLayerInfo() {

        HaiTuLayerInfo haiTuLayerInfo = new HaiTuLayerInfo();

        //baseUrl
        haiTuLayerInfo.setUrl(LayerInfoFactory.MAPURl);

//
        handleLayerInfo(haiTuLayerInfo);


        return haiTuLayerInfo;
    }


    private static void handleLayerInfo(HaiTuLayerInfo layerInfo) {

        layerInfo.setOrigin(LayerInfoFactory.ORIGIN_2000);

        //空间参考系
        layerInfo.setSrid(LayerInfoFactory.SRID_2000);

        layerInfo.setxMin(LayerInfoFactory.X_MIN_2000);
        layerInfo.setyMin(LayerInfoFactory.Y_MIN_2000);
        layerInfo.setxMax(LayerInfoFactory.X_MAX_2000);
        layerInfo.setyMax(LayerInfoFactory.Y_MAX_2000);


        layerInfo.setScales(LayerInfoFactory.SCALES);

        layerInfo.setResolutions(LayerInfoFactory.RESOLUTIONS_2000);

        layerInfo.setLods(getLods2000());

    }
}
*/
