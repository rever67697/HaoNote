package com.allhigh.gisdemo.map;


/**
 * Created by songke on 2018/4/23.
 */

/*
public class HaiTuImageLayer extends ImageTiledLayer {

    private HaiTuLayerInfo layerInfo;

    public HaiTuLayerInfo getLayerInfo() {
        return layerInfo;
    }

    public void setLayerInfo(HaiTuLayerInfo layerInfo) {
        this.layerInfo = layerInfo;
    }

    public HaiTuImageLayer(TileInfo tileInfo, Envelope fullExtent) {
        super(tileInfo, fullExtent);
    }

    @Override
    protected byte[] getTile(TileKey tileKey) {
        int level = tileKey.getLevel();
        int col = tileKey.getColumn();
        int row = tileKey.getRow();
        try {
            return getTile(level, col, row);
        } catch (Exception e) {
            return new byte[0];
        }
    }


    private byte[] getTile(int level, int col, int row) throws Exception {
        byte[] tileImage = null;
        if (layerInfo != null) {
            if (tileImage == null) {
                if (level > layerInfo.getMaxZoomLevel()
                        || level < layerInfo.getMinZoomLevel())
                    return new byte[0];
                String path = layerInfo.getUrl()
                        + "&x=" + col
                        + "&y=" + row
                        + "&z=" + (level)
                        + "&s=Gal";

                URL url = new URL(path);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                //获取服务器返回回来的流
                InputStream is = conn.getInputStream();
                tileImage = getBytes(is);
            }
        }
        return tileImage;
    }


    private byte[] getBytes(InputStream is) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int len = 0;
        while ((len = is.read(buffer)) != -1) {
            bos.write(buffer, 0, len);
        }
        is.close();
        bos.flush();
        byte[] result = bos.toByteArray();

        return result;
    }

}
*/
