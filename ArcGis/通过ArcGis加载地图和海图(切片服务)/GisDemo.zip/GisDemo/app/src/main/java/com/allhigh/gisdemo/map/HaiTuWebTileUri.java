package com.allhigh.gisdemo.map;

/**
 * Created by songke on 2018/4/23.
 */

public class HaiTuWebTileUri {

    public static String getTemplateUri() {
        //http://t0.tianditu.com/vec_c/wmts?service=wmts&request=gettile&
        // version=1.0.0&layer=vec
        // &STYLE=default&tilematrixset=c&tilematrix=3&tilerow=3&tilecol=4&format=tiles

        //  http://mt2.google.cn/vt/lyrs=m@180000000&hl=zh-CN&gl=cn&src=app&x=7&y=2&z=3&s=Gal

        String templateUri = "&x={level}&y={row}&z={col}" +
                "&s=Gal";

        String baseUrl = "http://mt2.google.cn/vt/lyrs=m@180000000&hl=zh-CN&gl=cn&src=app";


        return baseUrl + templateUri;
    }

}
