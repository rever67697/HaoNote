package com.allhigh.gisdemo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

import com.esri.android.map.MapView;


public class ZoomControlView extends RelativeLayout implements OnClickListener {

    private ImageButton mButtonZoomin;

    private ImageButton mButtonZoomout;

    private MapView mapView;


    public ZoomControlView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ZoomControlView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    @SuppressLint("InflateParams")
    private void init() {
        View view = LayoutInflater.from(getContext()).inflate(
                R.layout.zoom_controls_layout, null);
        mButtonZoomin = (ImageButton) view.findViewById(R.id.zoomin);
        mButtonZoomout = (ImageButton) view.findViewById(R.id.zoomout);
        mButtonZoomin.setOnClickListener(this);
        mButtonZoomout.setOnClickListener(this);
        addView(view);
    }

    @Override
    public void onClick(View v) {
        if (mapView == null) {
            throw new NullPointerException(
                    "you can call setMapView(MapView mapView) at first");
        }
        switch (v.getId()) {
            case R.id.zoomin: {
                double scale = mapView.getScale();

                //到达一定比例尺不让缩小
                mapView.zoomin();
                break;
            }
            case R.id.zoomout: {
                mapView.zoomout();
                break;
            }
            default:
                break;
        }
    }

    /**
     * 与MapView设置关联
     *
     * @param mapView
     */
    public void setMapView(MapView mapView) {
        this.mapView = mapView;
    }
}
